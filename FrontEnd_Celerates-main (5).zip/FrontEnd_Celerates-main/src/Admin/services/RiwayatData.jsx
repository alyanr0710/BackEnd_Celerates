const RiwayatData = [
  {
    idPesanan: "#25426",
    tanggal: "Oct 30, 2024",
    namaUser: "Siti",
    status: "Proses",
    jumlah: 75000,
    produk: "Jenang Krasikan isi 32",
  },
  {
    idPesanan: "#25425",
    tanggal: "Oct 30, 2024",
    namaUser: "Joko",
    status: "Dibatalkan",
    jumlah: 290000,
    produk: "Blouse batik kekinian",
  },
  {
    idPesanan: "#25424",
    tanggal: "Oct 29, 2024",
    namaUser: "Cece",
    status: "Proses",
    jumlah: 250000,
    produk: "Kemeja Batik Solo",
  },
  {
    idPesanan: "#25423",
    tanggal: "Oct 29, 2024",
    namaUser: "Suminem",
    status: "Dibatalkan",
    jumlah: 100000,
    produk: "Lumpia Semarang",
  },
  {
    idPesanan: "#25422",
    tanggal: "Oct 29, 2024",
    namaUser: "Eli",
    status: "Selesai",
    jumlah: 10000,
    produk: "Balung Kethuk",
  },
];

export default RiwayatData;
