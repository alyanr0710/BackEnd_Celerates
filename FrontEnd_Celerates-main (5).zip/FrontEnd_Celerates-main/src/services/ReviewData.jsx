const ReviewData = [
    {
      reviewer: "Nanda Shinta",
      rating: 4,
      review: "Website ini sangat membantu! Dari mulai camilan hingga kerajinan khas Jawa Tengah, semua ada di sini. Pengiriman cepat dan produk sampai dalam kondisi baik. Benar-benar pengalaman belanja yang memuaskan.",
      profileImage: "/assets/images/org5.jpg",
    },
    {
      reviewer: "Rani Aprilia",
      rating: 5,
      review: "Saya sangat senang belanja di sini! Produk-produknya unik dan kualitasnya sangat bagus. Saya bisa mendapatkan berbagai barang khas Jawa Tengah tanpa perlu jauh-jauh ke sana. Pengirimannya juga cepat dan aman. Terima kasih!",
      profileImage: "/assets/images/org3.jpeg",
    },
    {
      reviewer: "Andi Prasetyo",
      rating: 5,
      review: "Saya sangat terkesan dengan pengalaman berbelanja di website ini! Produk-produk khas Jawa Tengahnya berkualitas tinggi, terutama batik yang saya pesan. Proses pembelian sangat mudah dan cepat, dan pengiriman tepat waktu. Saya pasti akan kembali untuk membeli lebih banyak produk!",
      profileImage: "/assets/images/org1.jpeg",
    },
    {
      reviewer: "Rendi Santoso",
      rating: 4,
      review: "Website yang user-friendly dan proses pembelian sangat mudah. Saya senang bisa menemukan produk-produk otentik khas Jawa Tengah tanpa repot. Terima kasih sudah menyediakan layanan yang memudahkan!",
      profileImage: "/assets/images/org2.jpeg",
    },
    {
      reviewer: "Yoga Prabowo",
      rating: 5,
      review: "Website yang user-friendly dan proses pembelian sangat mudah. Saya senang bisa menemukan produk-produk otentik khas Jawa Tengah tanpa repot. Terima kasih sudah menyediakan layanan yang memudahkan!",
      profileImage: "/assets/images/org4.png",
    },
    {
      reviewer: "Yoga Prabowo",
      rating: 5,
      review: "Website yang user-friendly dan proses pembelian sangat mudah. Saya senang bisa menemukan produk-produk otentik khas Jawa Tengah tanpa repot. Terima kasih sudah menyediakan layanan yang memudahkan!",
      profileImage: "/assets/images/org4.png",
    },
    {
      reviewer: "Yoga Prabowo",
      rating: 5,
      review: "Website yang user-friendly dan proses pembelian sangat mudah. Saya senang bisa menemukan produk-produk otentik khas Jawa Tengah tanpa repot. Terima kasih sudah menyediakan layanan yang memudahkan!",
      profileImage: "/assets/images/org4.png",
    },
  ];
  
  export default ReviewData;