export const cartData = [
  {
    id: 1,
    name: "Dompet anyaman",
    details: "merah, hitam",
    price: 30000,
    quantity: 1,
    image: "/assets/images/K_DOMPETANYAM.jpeg",
  },
  {
    id: 2,
    name: "Sling bag anyaman rotan asli Solo",
    details: "lingkaran, tali polos",
    price: 60000,
    quantity: 1,
    image: "/assets/images/K_SLIMBAGROTAN.jpeg",
    status: "Sedang diproses",
  },
  {
    id: 3,
    name: "Blouse Batik Kekinian",
    details: "Biru, L",
    price: 270000,
    quantity: 1,
    image: "/assets/images/batikbiru.png",
  },
];
